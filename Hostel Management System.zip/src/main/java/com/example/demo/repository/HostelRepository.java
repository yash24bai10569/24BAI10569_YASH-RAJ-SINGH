package com.example.demo.repository;

import com.example.demo.model.Hostel;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface HostelRepository extends MongoRepository<Hostel, String> {

}