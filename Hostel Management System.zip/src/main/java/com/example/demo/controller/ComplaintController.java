package com.example.demo.controller;

import com.example.demo.model.Complaint;
import com.example.demo.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/complaints")
public class ComplaintController {

    @Autowired
    private ComplaintService service;

    @PostMapping
    public Complaint registerComplaint(@RequestBody Complaint complaint) {
        return service.registerComplaint(complaint);
    }

    @GetMapping
    public List<Complaint> getAllComplaints() {
        return service.getAllComplaints();
    }

    @GetMapping("/status/{status}")
    public List<Complaint> getByStatus(@PathVariable String status) {
        return service.getByStatus(status);
    }

    @PutMapping("/{id}/status")
    public Complaint updateStatus(@PathVariable String id, @RequestParam String status) {
        return service.updateStatus(id, status);
    }

    @PutMapping("/{id}/assign")
    public Complaint assignStaff(@PathVariable String id, @RequestParam String staffId) {
        return service.assignStaff(id, staffId);
    }

    @DeleteMapping("/{id}")
    public String deleteComplaint(@PathVariable String id) {
        service.deleteComplaint(id);
        return "Complaint deleted successfully";
    }
}