package com.example.demo.controller;

import com.example.demo.model.Fee;
import com.example.demo.service.FeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/fees")
public class FeeController {

    @Autowired
    private FeeService service;

    @PostMapping
    public Fee addFee(@RequestBody Fee fee) {
        return service.addFee(fee);
    }

    @GetMapping
    public List<Fee> getAllFees() {
        return service.getAllFees();
    }

    @GetMapping("/pending")
    public List<Fee> getPendingFees() {
        return service.getPendingFees();
    }

    @GetMapping("/student/{studentId}")
    public List<Fee> getFeesByStudent(@PathVariable String studentId) {
        return service.getFeesByStudent(studentId);
    }

    @PutMapping("/{id}/pay")
    public Fee markAsPaid(@PathVariable String id) {
        return service.markAsPaid(id);
    }

    @DeleteMapping("/{id}")
    public String deleteFee(@PathVariable String id) {
        service.deleteFee(id);
        return "Fee record deleted successfully";
    }
}
