package com.example.demo.controller;

import com.example.demo.model.Staff;
import com.example.demo.service.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/staff")
public class StaffController {

    @Autowired
    private StaffService service;

    @PostMapping
    public Staff saveStaff(@RequestBody Staff staff) {
        return service.saveStaff(staff);
    }

    @GetMapping
    public List<Staff> getAllStaff() {
        return service.getAllStaff();
    }

    @GetMapping("/{id}")
    public Staff getStaff(@PathVariable String id) {
        return service.getStaffById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteStaff(@PathVariable String id) {
        service.deleteStaff(id);
    }
}