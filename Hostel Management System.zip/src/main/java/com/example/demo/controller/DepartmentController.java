package com.example.demo.controller;

import com.example.demo.model.Department;
import com.example.demo.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/departments")
public class DepartmentController {

    @Autowired
    private DepartmentService service;

    @PostMapping
    public Department saveDepartment(@RequestBody Department department) {
        System.out.println("Received Name = " + department.getDepartmentName());
        Department saved = service.saveDepartment(department);
        System.out.println("Saved Name = " + saved.getDepartmentName());
        return saved;
    }

    @GetMapping
    public List<Department> getAllDepartments() {
        return service.getAllDepartments();
    }

    @GetMapping("/{id}")
    public Department getDepartment(@PathVariable String id) {
        return service.getDepartmentById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteDepartment(@PathVariable String id) {
        service.deleteDepartment(id);
    }
}