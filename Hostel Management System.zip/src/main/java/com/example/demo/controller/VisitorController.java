package com.example.demo.controller;

import com.example.demo.model.Visitor;
import com.example.demo.service.VisitorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/visitors")
public class VisitorController {

    @Autowired
    private VisitorService service;

    @PostMapping
    public Visitor addVisitor(@RequestBody Visitor visitor) {
        return service.addVisitor(visitor);
    }

    @GetMapping
    public List<Visitor> getAllVisitors() {
        return service.getAllVisitors();
    }

    @GetMapping("/student/{studentId}")
    public List<Visitor> getByStudent(@PathVariable String studentId) {
        return service.getVisitorsByStudent(studentId);
    }

    @DeleteMapping("/{id}")
    public String deleteVisitor(@PathVariable String id) {
        service.deleteVisitor(id);
        return "Visitor deleted successfully";
    }
}