package com.example.demo.controller;

import com.example.demo.model.Hostel;
import com.example.demo.service.HostelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hostels")
public class HostelController {

    @Autowired
    private HostelService service;

    @PostMapping
    public Hostel saveHostel(@RequestBody Hostel hostel) {
        return service.saveHostel(hostel);
    }

    @GetMapping
    public List<Hostel> getAllHostels() {
        return service.getAllHostels();
    }

    @GetMapping("/{id}")
    public Hostel getHostel(@PathVariable String id) {
        return service.getHostelById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteHostel(@PathVariable String id) {
        service.deleteHostel(id);
    }
}