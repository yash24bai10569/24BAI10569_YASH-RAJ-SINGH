package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "hostels")
public class Hostel {

    @Id
    private String id;

    private String hostelName;
    private String hostelType;

    public Hostel() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getHostelName() { return hostelName; }
    public void setHostelName(String hostelName) { this.hostelName = hostelName; }

    public String getHostelType() { return hostelType; }
    public void setHostelType(String hostelType) { this.hostelType = hostelType; }
}