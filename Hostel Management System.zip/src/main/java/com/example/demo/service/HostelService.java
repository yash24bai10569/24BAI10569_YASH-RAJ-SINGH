package com.example.demo.service;

import com.example.demo.model.Hostel;
import com.example.demo.repository.HostelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HostelService {

    @Autowired
    private HostelRepository repository;

    public Hostel saveHostel(Hostel hostel) {
        return repository.save(hostel);
    }

    public List<Hostel> getAllHostels() {
        return repository.findAll();
    }

    public Hostel getHostelById(String id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteHostel(String id) {
        repository.deleteById(id);
    }
}
