package com.example.demo.service;

import com.example.demo.model.Complaint;
import com.example.demo.repository.ComplaintRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ComplaintService {

    @Autowired
    private ComplaintRepository repository;

    public Complaint registerComplaint(Complaint complaint) {
        complaint.setStatus("Pending");
        return repository.save(complaint);
    }

    public List<Complaint> getAllComplaints() {
        return repository.findAll();
    }

    public List<Complaint> getByStatus(String status) {
        return repository.findByStatus(status);
    }

    public Complaint updateStatus(String id, String status) {
        Complaint complaint = repository.findById(id).orElse(null);
        if (complaint != null) {
            complaint.setStatus(status);
            return repository.save(complaint);
        }
        return null;
    }

    public Complaint assignStaff(String id, String staffId) {
        Complaint complaint = repository.findById(id).orElse(null);
        if (complaint != null) {
            complaint.setAssignedStaffId(staffId);
            complaint.setStatus("In Progress");
            return repository.save(complaint);
        }
        return null;
    }

    public void deleteComplaint(String id) {
        repository.deleteById(id);
    }
}