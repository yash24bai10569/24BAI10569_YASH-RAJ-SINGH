package com.example.demo.service;

import com.example.demo.model.Fee;
import com.example.demo.repository.FeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FeeService {

    @Autowired
    private FeeRepository repository;

    public Fee addFee(Fee fee) {
        fee.setStatus("Pending");
        return repository.save(fee);
    }

    public List<Fee> getAllFees() {
        return repository.findAll();
    }

    public List<Fee> getPendingFees() {
        return repository.findByStatus("Pending");
    }

    public List<Fee> getFeesByStudent(String studentId) {
        return repository.findByStudentId(studentId);
    }

    public Fee markAsPaid(String id) {
        Fee fee = repository.findById(id).orElse(null);
        if (fee != null) {
            fee.setStatus("Paid");
            return repository.save(fee);
        }
        return null;
    }

    public void deleteFee(String id) {
        repository.deleteById(id);
    }
}