package com.example.demo.service;

import com.example.demo.model.Visitor;
import com.example.demo.repository.VisitorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class VisitorService {

    @Autowired
    private VisitorRepository repository;

    public Visitor addVisitor(Visitor visitor) {
        visitor.setVisitDate(LocalDateTime.now());
        return repository.save(visitor);
    }

    public List<Visitor> getAllVisitors() {
        return repository.findAll();
    }

    public List<Visitor> getVisitorsByStudent(String studentId) {
        return repository.findByStudentId(studentId);
    }

    public void deleteVisitor(String id) {
        repository.deleteById(id);
    }
}