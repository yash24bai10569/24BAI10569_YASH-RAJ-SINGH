package com.example.demo.service;

import com.example.demo.model.Staff;
import com.example.demo.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StaffService {

    @Autowired
    private StaffRepository repository;

    public Staff saveStaff(Staff staff) {

        System.out.println("Received Staff:");
        System.out.println("Name = " + staff.getName());
        System.out.println("Designation = " + staff.getDesignation());
        System.out.println("Phone = " + staff.getPhone());
        System.out.println("HostelId = " + staff.getHostelId());

        return repository.save(staff);
    }

    public List<Staff> getAllStaff() {
        return repository.findAll();
    }

    public Staff getStaffById(String id) {
        return repository.findById(id).orElse(null);
    }

    public void deleteStaff(String id) {
        repository.deleteById(id);
    }
}