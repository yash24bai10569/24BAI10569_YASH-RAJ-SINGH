package com.example.demo.service;

import com.example.demo.model.Room;
import com.example.demo.repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RoomService {

    @Autowired
    private RoomRepository repository;

    public Room addRoom(Room room) {
        return repository.save(room);  // 

    public List<Room> getAllRooms() {
        return repository.findAll();
    }

    public Room getRoomById(String id) {
        return repository.findById(id).orElse(null);
    }

    public Room updateRoom(String id, Room updated) {
        updated.setId(id);
        return repository.save(updated);
    }

    public void deleteRoom(String id) {
        repository.deleteById(id);
    }
}